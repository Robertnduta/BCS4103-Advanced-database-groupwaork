<?php
$db=pg_connect('host=localhost dbname=delicook user=postgres password=2536');
if($db) {
  //  echo  'connected';
   } else {
    //   echo 'there has been an error connecting';
   }

?>
